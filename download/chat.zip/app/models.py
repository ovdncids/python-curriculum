from django.db import models
from django.contrib.auth.models import User

class Profiles(models.Model):
  profile_id = models.AutoField(primary_key=True)
  user = models.ForeignKey(User, on_delete=models.CASCADE)
  profile_file_path = models.CharField(max_length = 500)
  name = models.CharField(max_length = 200)
  gender = models.CharField(max_length = 1)
  neuter = models.BooleanField(default=False)
  region = models.CharField(max_length = 20)
  species = models.CharField(max_length = 200)
  birth_year = models.IntegerField(default = 2021)
  weight = models.IntegerField(default = 1)
  introduce = models.CharField(max_length = 100)

class Chats(models.Model):
  chat_id = models.AutoField(primary_key=True)
  host_profile = models.ForeignKey(Profiles, related_name='host_profile', on_delete=models.DO_NOTHING)
  guest_profile = models.ForeignKey(Profiles, related_name='guest_profile', on_delete=models.DO_NOTHING)
  create_at = models.DateTimeField(auto_now_add=True)

class Messages(models.Model):
  message_id = models.AutoField(primary_key=True)
  chat = models.ForeignKey(Chats, related_name='chat', on_delete=models.CASCADE)
  profile = models.ForeignKey(Profiles, related_name='profile', on_delete=models.DO_NOTHING)
  message = models.CharField(max_length = 200)
  create_at = models.DateTimeField(auto_now_add=True)
