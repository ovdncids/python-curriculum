from django import forms

class UserForm(forms.Form):
    id = forms.CharField(label='User ID', error_messages={'required': 'Please enter your ID'})
    password = forms.CharField(label='User Password', error_messages={'required': 'Please enter your Password'})
    email = forms.EmailField(label='User E-mail', error_messages={'required': 'Please enter your E-mail'})
    tel = forms.CharField(label='User Phone Number', error_messages={'required': 'Please enter your Phone Number'})

class RegistrationForm(forms.Form):
    profile_file_path = forms.CharField(label='User profile file', error_messages={'required': '사진을 등록하세요.'})
    name = forms.CharField(label='User name', error_messages={'required': '이름을 입력하세요.'})
    gender = forms.CharField(label='User gender', error_messages={'required': '성별을 선택하세요.'})
    region = forms.CharField(label='User region', error_messages={'required': '지역을 선택하세요.'})
    species = forms.CharField(label='User species', error_messages={'required': '견종을 입력하세요.'})
    birth_year = forms.CharField(label='User birth_year', error_messages={'required': '생일연도를 선택하세요.'})
    weight = forms.CharField(label='User weight', error_messages={'required': '몸무게를 입력하세요.'})
    introduce = forms.CharField(label='User introduce', error_messages={'required': '소개를 적어주세요.'})
