from django.shortcuts import render, redirect
from app.forms import UserForm, RegistrationForm
from django.contrib.auth.models import User
from django.contrib import auth
import json
from django.core.files.storage import FileSystemStorage
from app.models import Profiles, Chats, Messages

# Create your views here.
def home(request):
  region = request.GET.get('region')
  if region == None:
    profiles = Profiles.objects.all()
  else:
    profiles = Profiles.objects.filter(region=region)
  return render(request, 'home.html', {'profiles': profiles})

def signup(request):
    if request.method == 'POST': 
        form = UserForm(request.POST) # form태그에서 넘어온 값들을 forms.py에 설정된 형식과 비교한다.
        if form.is_valid():
          found_id = User.objects.filter(username=request.POST['id'])
          if (len(found_id) > 0):
            return render(request, 'signup.html', {'errors': {
              'id': [{'message': 'The ID that already exists.'}]
            }})
          else:
            request.session['id'] = request.POST['id']
            request.session['password'] = request.POST['password']
            request.session['email'] = request.POST['email']
            request.session['tel'] = request.POST['tel']
            return redirect('registration')
        else:
          # error = json.loads(form.errors.as_json())
          # print(error['id'])
          # print(error['id'][0])
          # print(error['id'][0]['message'])
          return render(request, 'signup.html', {'errors': json.loads(form.errors.as_json())})
          # return render(request, 'signup.html', {'errors': form.errors})
    return render(request, 'signup.html', {'form': {
      'id': 'id',
      'password': 'pw',
      'email': 'a@a.com',
      'tel': '010-1234-5678'
    }})

def login(request):
  if request.method == 'POST':
    found_user = auth.authenticate(
        username = request.POST['id'],
        password = request.POST['password'],
    )
    if found_user == None:
      return render(request, 'login.html', {'errors': {
        'id_password': [{'message': '아이디 또는 비밀번호가 맞지 않습니다.'}]
      }})
    else:
      auth.login(request, found_user)
      # print(request.user)
      return redirect('home')
  return render(request, 'login.html')


def logout(request):
  auth.logout(request)
  return redirect('login')


def chat(request):
  if request.GET.get('host_profile_id') != None:
    host_profile = Profiles.objects.get(profile_id = request.GET.get('host_profile_id'))
    guest_profile = Profiles.objects.get(user_id = request.user.id)
    chats = Chats.objects.filter(
      host_profile = host_profile,
      guest_profile = guest_profile
    ) | Chats.objects.filter(
      host_profile = guest_profile,
      guest_profile = host_profile
    )
    if len(chats) == 0:
      chat = Chats.objects.create(
        host_profile = host_profile,
        guest_profile = guest_profile
      )
      return redirect('/chat/?chat_id=' + str(chat.chat_id))
    else:
      return redirect('/chat/?chat_id=' + str(chats[0].chat_id))
  chat = Chats.objects.get(chat_id = request.GET.get('chat_id', request.POST.get('chat_id')))
  profile = Profiles.objects.get(user_id = request.user.id)
  if request.method == 'POST':
    Messages.objects.create(
      chat = chat,
      profile = profile,
      message = request.POST.get('message')
    )
    return redirect('/chat/?chat_id=' + str(chat.chat_id))
  messages = Messages.objects.filter(chat_id = chat.chat_id)
  return render(request, 'chat.html', {
    'chat': chat,
    'messages': messages
  })

def chatlist(request):
  profile = Profiles.objects.get(user_id = request.user.id)
  chats = Chats.objects.filter(host_profile = profile) | Chats.objects.filter(guest_profile = profile)
  return render(request, 'chatlist.html', {'chats': chats})

def registration_file(request):
  profile_file = request.FILES['profile_file'] # 폼에서 넘어온 파일을 받는다.
  fs = FileSystemStorage() # 파일을 컨트롤할 수 있는 객체를 생성한다.
  filename = fs.save('./app/static/profile_files/' + profile_file.name, profile_file) # 첫번째 인수는 파일의 경로, 두번째 인수는 넘어온 파일
  profile_file_path = fs.url(filename)
  print(profile_file_path)
  return profile_file_path

def registration(request):
  print(request.session.get('id'))
  if request.session.get('id') == None or request.session.get('password') == None or request.session.get('email') == None or request.session.get('tel') == None:
    return redirect('signup')
  if request.method == 'POST':
    if request.POST['is_file_upload'] == 'true':
      profile_file_path = registration_file(request)
      return render(request, 'registration.html', {
        'form': {
          'profile_file_path': profile_file_path.replace('/app/static/', ''),
          'name': request.POST['name'],
          'gender': request.POST.get('gender'),
          'neuter': request.POST.get('neuter'),
          'region': request.POST['region'],
          'species': request.POST['species'],
          'birth_year': request.POST['birth_year'],
          'weight': request.POST['weight'],
          'introduce': request.POST['introduce'],
        }
      })
    else:
      registrationForm = RegistrationForm(request.POST)
      if registrationForm.is_valid():
        user = User.objects.create_user(
            username = request.session['id'],
            email = request.session['email'],
            password = request.session['password'],
            last_name = request.session['tel'],
        )
        neuter = True if request.POST.get('neuter') == 'neuter' else False
        profiles = Profiles.objects.create(
          user = user,
          profile_file_path = request.POST['profile_file_path'],
          name = request.POST['name'],
          gender = request.POST['gender'],
          neuter = neuter,
          region = request.POST['region'],
          species = request.POST['species'],
          birth_year = request.POST['birth_year'],
          weight = request.POST['weight'],
          introduce = request.POST['introduce'],
        )
        del request.session['id']
        del request.session['email']
        del request.session['password']
        del request.session['tel']
        return redirect('complete')
      else:
        return render(request, 'registration.html', {
          'form': {
            'profile_file_path': request.POST['profile_file_path'],
            'name': request.POST['name'],
            'gender': request.POST.get('gender'),
            'neuter': request.POST.get('neuter'),
            'region': request.POST['region'],
            'species': request.POST['species'],
            'birth_year': request.POST['birth_year'],
            'weight': request.POST['weight'],
            'introduce': request.POST['introduce'],
          },
          'errors': json.loads(registrationForm.errors.as_json())
        })
  return render(request, 'registration.html')

def mypage(request):
  if request.user.id == None:
    return redirect('login')
  profiles = Profiles.objects.filter(user_id = request.user.id)
  profile = profiles[0]
  if request.method == 'POST':
    if request.POST['is_file_upload'] == 'true':
      profile_file_path = registration_file(request)
      return render(request, 'mypage.html', {
        'form': {
          'profile_file_path': profile_file_path.replace('/app/static/', ''),
          'name': request.POST['name'],
          'gender': request.POST.get('gender'),
          'neuter': request.POST.get('neuter'),
          'region': request.POST['region'],
          'species': request.POST['species'],
          'birth_year': request.POST['birth_year'],
          'weight': request.POST['weight'],
          'introduce': request.POST['introduce'],
        }
      })
    else:
      registrationForm = RegistrationForm(request.POST)
      if registrationForm.is_valid():
        profile.profile_file_path = request.POST['profile_file_path']
        profile.save()
        return render(request, 'mypage.html', {
          'form': profile,
          'message': '수정 되었습니다.'
        })
      else:
        return render(request, 'mypage.html', {
          'form': {
            'profile_file_path': request.POST['profile_file_path'],
            'name': request.POST['name'],
            'gender': request.POST.get('gender'),
            'neuter': request.POST.get('neuter'),
            'region': request.POST['region'],
            'species': request.POST['species'],
            'birth_year': request.POST['birth_year'],
            'weight': request.POST['weight'],
            'introduce': request.POST['introduce'],
          },
          'errors': json.loads(registrationForm.errors.as_json())
        })
  return render(request, 'mypage.html', {'form': profile})

def complete(request):
  return render(request, 'complete.html')
