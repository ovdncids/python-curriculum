const getOTP = function(button) {
  button.disabled = true;
  const email = button.form['email'].value;
  if (!email) {
    alert('이메일을 입력하세요.');
    return;
  }
  const xhrObject = new XMLHttpRequest();
  xhrObject.onreadystatechange = function() {
    if (xhrObject.readyState !== 4) return;
    if (xhrObject.status === 200) {
      // 통신 완료 후 실행할 부분
      console.log('Done', xhrObject.responseText);
      window.OTP = JSON.parse(xhrObject.responseText).opt
      button.innerHTML = '인증번호 발송 완료';
    } else {
      // 통신 도중 에러가 발생 할때 실행할 부분
      const error = {
        status: xhrObject.status,
        statusText: xhrObject.statusText,
        responseText: xhrObject.responseText
      }
      console.error(error);
      alert('인증번호 발송이 실패했습니다.');
      button.disabled = false;
    }
  };
  xhrObject.open('GET', '/email/opt?email=' + email);
  xhrObject.setRequestHeader('Content-Type', 'application/json');
  xhrObject.send();
}

const checkOPT = function(button) {
  const opt = button.form['opt'].value;
  if (window.OTP === opt) {
    console.log('성공');
    button.innerHTML = '완료';
    document.getElementById('signup-button').style.visibility = 'visible';
  } else {
    console.log('실패');
  }
}

const signupSubmit = function(button) {
  button.disabled = true;
  document.getElementById('same_id').style.display = 'none';
  document.getElementById('not_same_password').style.display = 'none';
  document.getElementById('same_nickname').style.display = 'none';
  document.getElementById('not_same_opt').style.display = 'none';
  // if (form['password'].value !== form['password_confirm'].value) {
  //   document.querySelector('.message-password').style.display = 'inline';
  //   return false;
  // }
  const formData = new FormData(button.form);
  const xhrObject = new XMLHttpRequest();
  xhrObject.onreadystatechange = function() {
    if (xhrObject.readyState !== 4) return;
    if (xhrObject.status === 200) {
      // 통신 완료 후 실행할 부분
      console.log('Done', xhrObject.responseText);
      const result = JSON.parse(xhrObject.responseText);
      if (result.error) {
        for (let key in result.error) {
          document.getElementById(key).style.display = 'inline';
        }
        button.disabled = false;
      } else {
        window.location.href = '/signup_done';
      }
    } else {
      // 통신 도중 에러가 발생 할때 실행할 부분
      const error = {
        status: xhrObject.status,
        statusText: xhrObject.statusText,
        responseText: xhrObject.responseText
      }
      console.error(error);
      alert('서버에서 에러가 발생 하였습니다.');
      button.disabled = false;
    }
  };
  xhrObject.open('POST', '');
  // xhrObject.setRequestHeader('Content-Type', 'application/json');
  xhrObject.send(formData);
}
