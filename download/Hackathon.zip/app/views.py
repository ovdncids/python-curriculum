from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.contrib import auth
from django.core.mail import EmailMessage
import random

def home(request):
    return render(request, 'home.html')

def login(request):
    if (request.method == 'POST'):
        found_user = auth.authenticate(
            username = request.POST['id'],
            password = request.POST['password'],
        )
        if (found_user is None):
            error = '아이디 또는 비밀번호가 틀렸습니다'
            return render(request, 'login.html', {'error' : error})
        auth.login(request, found_user)
        return redirect('home') # TODO: 패이지 생기면 수정
    return render(request, 'login.html')

def signup(request):
    if (request.method == 'POST'): # 폼 태그에서 넘어왔을 경우
        error = {}
        found_username = User.objects.filter(username=request.POST['id'])
        found_nickname = User.objects.filter(last_name=request.POST['nickname'])
        if (len(found_username) > 0):
            error['same_id'] = True
        if (request.POST['password'] != request.POST['password_confirm']):
            error['not_same_password'] = True
        if (len(found_nickname) > 0):
            error['same_nickname'] = True
        if (request.session.get('opt') != request.POST['opt']):
            error['not_same_opt'] = True
        if (len(error) > 0):
            result = {"done": False, "error": error}
        else:
            new_user = User.objects.create_user(
                username = request.POST['id'], # id 사용
                first_name = request.POST['username'],
                password = request.POST['password'],
                last_name = request.POST['nickname'],
                email = request.POST['email'] + '@korea.ac.kr',
            )
            result = {"done": True}
        # auth.login(request, new_user)
        return JsonResponse(result)
    return render(request, 'signup.html')

def signup_done(request):
    return render(request, 'signup_done.html')

def email_opt(request):
    email = request.GET['email'] + '@nate.com'
    try:
        opt = str(random.randrange(0, 10))
        opt += str(random.randrange(0, 10))
        opt += str(random.randrange(0, 10))
        opt += str(random.randrange(0, 10))
        opt += str(random.randrange(0, 10))
        opt += str(random.randrange(0, 10))
        print(opt)
        email = EmailMessage('KUGETHER OTP Code Message', opt, to=[email])
        if (email.send() == 1):
            result = {"done": True, "opt": opt}
            request.session['opt'] = opt
        else:
            result = {"done": False}
    except:
        result = {"done": False}
    return JsonResponse(result)
