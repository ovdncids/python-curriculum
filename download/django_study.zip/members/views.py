from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Member

def members_read(request):
    return render(request, 'members.html', {
        'active_members': 'active',
        'members': Member.objects.all(),
    })

def members_create(request):
    id = Member.objects.create(
      name = request.POST['name'],
      age = request.POST['age'],
    )
    print('Done members_create', Member.objects.get(id=id.pk))
    return redirect('members/')

def members_update(request, index):
    member = Member.objects.get(id=index)
    member.name = request.POST['name']
    member.age = request.POST['age']
    member.save()
    print('Done members_update', member)
    return redirect('/members/')

def members_delete(request, index):
    member = Member.objects.get(id=index)
    member.delete()
    print('Done members_delete', member)
    return redirect('/members/')

def search(request):
    q = request.GET.get('q', '')
    print(q)
    return render(request, 'search.html', {
      'active_search': 'active',
      'q': q,
      'members': Member.objects.filter(name__contains=q),
    })

def root(request):
    return redirect('members/')
